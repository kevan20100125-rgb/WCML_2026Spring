from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Sequence

import numpy as np

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from ofdm_detection_core import (
    OfdmConfig,
    bit_error_rate,
    load_channel_dataset,
    make_dnn_dataset,
    make_pilot_config,
    output_slices,
)
from run_ofdm_detection import (
    PILOT_CONFIG_SEED,
    build_model,
    device_from_arg,
    feature_stats,
    normalize_feature_matrix,
    require_torch,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Group-level FC-DNN overfit diagnostic for OFDM detection")
    parser.add_argument("--channel-root", type=Path, default=Path("../H_dataset"))
    parser.add_argument("--modulation", default="qpsk", choices=["qpsk", "qam64"])
    parser.add_argument("--mode", default="eight", choices=["eight", "single"])
    parser.add_argument("--group-id", type=int, default=0)
    parser.add_argument("--pilots", type=int, default=64)
    parser.add_argument("--snr-db", type=float, default=20.0)
    parser.add_argument("--train-samples", type=int, default=512)
    parser.add_argument("--heldout-samples", type=int, default=512)
    parser.add_argument("--epochs", type=int, default=200)
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--channel-rows-per-file", type=int, default=128)
    parser.add_argument("--hidden", type=int, nargs="+", default=[500, 250, 120])
    parser.add_argument("--device", default="auto")
    parser.add_argument("--seed", type=int, default=2026)
    return parser.parse_args()


def train_debug_model(
    x_train: np.ndarray,
    y_train: np.ndarray,
    hidden: Sequence[int],
    epochs: int,
    batch_size: int,
    learning_rate: float,
    device,
):
    torch, nn, optim = require_torch()
    model = build_model(x_train.shape[1], y_train.shape[1], hidden).to(device)
    optimizer = optim.RMSprop(model.parameters(), lr=learning_rate)
    loss_fn = nn.BCEWithLogitsLoss()
    x_tensor = torch.from_numpy(x_train).to(device)
    y_tensor = torch.from_numpy(y_train.astype(np.float32)).to(device)
    n = x_tensor.shape[0]
    for epoch in range(epochs):
        order = torch.randperm(n, device=device)
        losses = []
        for start in range(0, n, batch_size):
            idx = order[start:start + batch_size]
            logits = model(x_tensor[idx])
            loss = loss_fn(logits, y_tensor[idx])
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            losses.append(float(loss.detach().cpu()))
        if epoch == 0 or (epoch + 1) % max(1, epochs // 10) == 0 or epoch + 1 == epochs:
            print(json.dumps({"epoch": epoch + 1, "loss": float(np.mean(losses))}, sort_keys=True))
    return model


def predict_bits(model, x: np.ndarray, device) -> np.ndarray:
    torch, _, _ = require_torch()
    model.eval()
    with torch.no_grad():
        logits = model(torch.from_numpy(x.astype(np.float32)).to(device))
        return (torch.sigmoid(logits).detach().cpu().numpy() >= 0.5).astype(np.int64)


def main() -> None:
    args = parse_args()
    cfg = OfdmConfig(k=64, cp=16, with_cp=True, clipping=False)
    train_channels, test_channels = load_channel_dataset(args.channel_root, rows_per_file=args.channel_rows_per_file)
    slices = output_slices(cfg.k, args.modulation, args.mode)
    if args.group_id < 0 or args.group_id >= len(slices):
        raise SystemExit(f"group-id must be in [0, {len(slices) - 1}]")
    target_slice = slices[args.group_id]
    pilot_cfg = make_pilot_config(cfg.k, args.pilots, args.modulation, seed=PILOT_CONFIG_SEED)

    rng_train = np.random.default_rng(args.seed)
    x_train_raw, y_train, _ = make_dnn_dataset(
        args.train_samples,
        train_channels,
        args.snr_db,
        cfg,
        pilot_cfg,
        args.modulation,
        target_slice,
        rng_train,
    )
    feature_mean, feature_std = feature_stats(x_train_raw)
    x_train = normalize_feature_matrix(x_train_raw, feature_mean, feature_std)

    rng_heldout = np.random.default_rng(args.seed + 999)
    x_heldout_raw, y_heldout, _ = make_dnn_dataset(
        args.heldout_samples,
        test_channels,
        args.snr_db,
        cfg,
        pilot_cfg,
        args.modulation,
        target_slice,
        rng_heldout,
    )
    x_heldout = normalize_feature_matrix(x_heldout_raw, feature_mean, feature_std)

    device = device_from_arg(args.device)
    model = train_debug_model(
        x_train,
        y_train,
        args.hidden,
        args.epochs,
        args.batch_size,
        args.learning_rate,
        device,
    )

    train_pred = predict_bits(model, x_train, device)
    heldout_pred = predict_bits(model, x_heldout, device)
    result = {
        "diagnostic": "overfit_group",
        "modulation": args.modulation,
        "mode": args.mode,
        "group_id": args.group_id,
        "slice_start": int(target_slice.start),
        "slice_stop": int(target_slice.stop),
        "pilots": int(args.pilots),
        "snr_db": float(args.snr_db),
        "train_samples": int(args.train_samples),
        "heldout_samples": int(args.heldout_samples),
        "epochs": int(args.epochs),
        "train_group_ber": bit_error_rate(y_train.astype(np.int64), train_pred),
        "heldout_group_ber": bit_error_rate(y_heldout.astype(np.int64), heldout_pred),
        "pilot_config_seed": int(PILOT_CONFIG_SEED),
        "feature_normalized": True,
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
